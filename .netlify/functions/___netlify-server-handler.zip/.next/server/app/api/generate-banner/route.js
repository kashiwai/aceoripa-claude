(()=>{var e={};e.id=8578,e.ids=[8578],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},41589:(e,r,a)=>{"use strict";a.r(r),a.d(r,{patchFetch:()=>g,routeModule:()=>c,serverHooks:()=>d,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>u});var t={};a.r(t),a.d(t,{POST:()=>p});var n=a(96559),i=a(48088),o=a(37719),s=a(32190);async function p(e){try{let{type:r,text:a,style:t,title:n,subtitle:i}=await e.json(),o={"line-campaign":`
        Create a vibrant banner for LINE friend registration campaign in Japanese mobile game style.
        Text: "${a||"LINE友達登録で最大70%OFFクーポン!"}"
        Style: Green gradient background, LINE app logo, discount coupon visual, mobile-first design,
        bright yellow accent for discount percentage, professional game banner quality.
        Size: 375x80px mobile banner format.
      `,"gacha-main":`
        Create an exciting gacha game banner with Japanese text.
        Main text: "${a||"超絶ガチャ爆誕"}"
        Style: Purple to pink gradient, sparkles and stars, golden accents, epic game feel,
        Japanese mobile game aesthetic, premium quality, exciting atmosphere.
        Size: 375x200px hero banner.
      `,campaign:`
        Create a limited-time campaign banner for Japanese mobile game.
        Text: "${a||"期間限定キャンペーン"}"
        Style: Yellow to orange gradient, fire effects, urgency feeling, "LIMITED TIME" vibe,
        Japanese text prominent, mobile game UI style.
        Size: 375x100px.
      `,new:`
        Create a "NEW" banner for new products or features.
        Title: "${n||"新商品入荷"}"
        Subtitle: "${i||"最新ガチャ登場"}"
        Style: Modern, clean, eye-catching design with Japanese text.
      `,"sns-winner":`
        Create a social media winner announcement banner.
        Text: "${a||"SNS当選報告"}"
        Style: Celebration theme, confetti, trophy or prize visual, social media icons,
        exciting winner announcement feel, Japanese text.
        Size: 200x200px square format.
      `,"card-pack":`
        Create a trading card pack banner for online gacha.
        Text: "${a||"ポケモンカード151"}"
        Style: Holographic effect, trading card aesthetic, pack opening excitement,
        premium shiny finish, Japanese TCG style.
        Size: 400x600px vertical card format.
      `},p=o[r]||o["gacha-main"],c=process.env.OPENAI_API_KEY;if(!c||c.includes("xxx")||c.includes("..."))return console.warn("OpenAI API key not configured, returning placeholder"),s.NextResponse.json({success:!0,imageUrl:`/api/placeholder/400/400?text=${encodeURIComponent(n||a||"Banner")}`,revised_prompt:p,placeholder:!0});let l=new AbortController,u=setTimeout(()=>l.abort(),8e3);try{let e=await fetch("https://api.openai.com/v1/images/generations",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${c}`},body:JSON.stringify({model:"dall-e-3",prompt:p+" High quality, professional game asset, no watermarks.",n:1,size:"1024x1024",quality:"hd",style:t||"vivid"}),signal:l.signal});if(clearTimeout(u),!e.ok){let r=await e.json();throw console.error("OpenAI API error:",r),Error("Failed to generate image")}let r=await e.json();return s.NextResponse.json({success:!0,imageUrl:r.data[0].url,revised_prompt:r.data[0].revised_prompt})}catch(e){return clearTimeout(u),"AbortError"===e.name?console.error("Banner generation timeout"):console.error("Banner generation error:",e),s.NextResponse.json({success:!0,imageUrl:`/api/placeholder/400/400?text=${encodeURIComponent(r||"Banner")}`,revised_prompt:p,error:!0})}}catch(e){return console.error("Banner generation error:",e),s.NextResponse.json({success:!0,imageUrl:"/api/placeholder/400/400?text=Error",error:!0})}}let c=new n.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/generate-banner/route",pathname:"/api/generate-banner",filename:"route",bundlePath:"app/api/generate-banner/route"},resolvedPagePath:"/Users/kotarokashiwai/aceoripa/aceoripa/aceoripa-claude/src/app/api/generate-banner/route.ts",nextConfigOutput:"standalone",userland:t}),{workAsyncStorage:l,workUnitAsyncStorage:u,serverHooks:d}=c;function g(){return(0,o.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:u})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var r=require("../../../webpack-runtime.js");r.C(e);var a=e=>r(r.s=e),t=r.X(0,[4447,580],()=>a(41589));module.exports=t})();