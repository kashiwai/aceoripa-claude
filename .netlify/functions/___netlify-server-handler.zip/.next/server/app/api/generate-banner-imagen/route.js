(()=>{var e={};e.id=504,e.ids=[504],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},11997:e=>{"use strict";e.exports=require("punycode")},12412:e=>{"use strict";e.exports=require("assert")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57975:e=>{"use strict";e.exports=require("node:util")},60130:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>h,routeModule:()=>u,serverHooks:()=>m,workAsyncStorage:()=>d,workUnitAsyncStorage:()=>g});var a={};r.r(a),r.d(a,{POST:()=>c});var s=r(96559),n=r(48088),i=r(37719),o=r(32190);async function c(e){try{let{type:t,text:r,title:a,subtitle:s,style:n}=await e.json(),i={"dopa-main":`
        Create a DOPA-style online gacha banner with Japanese text.
        Title: "${a||"激レア確定オリパ"}"
        Subtitle: "${s||"SSR確率大幅UP中"}"
        Style: Bold red gradient (#FF0033 to #FF6B6B), white text with black outline, 
        gold accents, dynamic diagonal composition, explosive effect background,
        professional Japanese online gacha site design, mobile-optimized.
        Resolution: Ultra high quality, 4K
      `,"dopa-pokemon":`
        Create a Pokemon card gacha banner in DOPA style.
        Title: "${a||"ポケモンカード151"}"
        Subtitle: "${s||"リザードンex確率UP！"}"
        Style: Vibrant red-orange gradient with Pokemon elements, 
        holographic card effects, Japanese trading card game aesthetic,
        bold typography with shadow effects, mobile-first design.
        Include: Sparkles, card pack visual, excitement feel
      `,"dopa-campaign":`
        Create a limited-time campaign banner in DOPA online gacha style.
        Title: "${a||"期間限定キャンペーン"}"
        Subtitle: "${s||"10連ガチャ20%OFF"}"
        Style: Urgent red-yellow gradient, countdown timer visual,
        Japanese mobile game campaign style, fire effects,
        bold discount percentage display, eye-catching design.
        Include: Sale tags, limited time urgency
      `,"dopa-new":`
        Create a "NEW ARRIVAL" banner for DOPA-style gacha site.
        Title: "${a||"新商品入荷"}"
        Subtitle: "${s||"最新オリパ登場"}"
        Style: Modern gradient design with NEW badge, Japanese text emphasis,
        clean but exciting composition, mobile game banner aesthetic.
        Colors: Red primary (#FF0033), white text, gold accents
      `,"dopa-winner":`
        Create a winner announcement banner for DOPA-style site.
        Title: "${a||"大当たり続出！"}"
        Subtitle: "${s||"SSRカード当選報告"}"
        Style: Celebration theme with confetti, trophy icons,
        social proof design, Japanese gacha winner showcase.
        Include: Winner avatars, rare card visuals, excitement
      `,"dopa-line":`
        Create a LINE registration campaign banner in DOPA style.
        Title: "${a||"LINE友達登録キャンペーン"}"
        Subtitle: "${s||"今なら500円クーポンGET"}"
        Style: LINE green integrated with DOPA red, modern Japanese design,
        QR code placeholder, mobile-optimized layout.
        Include: LINE logo style, coupon visual, call-to-action
      `},c=i[t]||i["dopa-main"],u=process.env.GOOGLE_CLOUD_PROJECT,d=process.env.GOOGLE_CLOUD_LOCATION||"us-central1",g=process.env.GOOGLE_APPLICATION_CREDENTIALS;if(!u||!g){console.warn("Google Cloud credentials not configured, returning enhanced placeholder");let e=`/api/generate-dopa-placeholder?type=${t}&title=${encodeURIComponent(a||"")}&subtitle=${encodeURIComponent(s||"")}`;return o.NextResponse.json({success:!0,imageUrl:e,revised_prompt:c,placeholder:!0,engine:"canvas-placeholder"})}try{let e=`https://${d}-aiplatform.googleapis.com/v1/projects/${u}/locations/${d}/publishers/google/models/imagen-3.0-generate-001:predict`,r={instances:[{prompt:c,image_size:"1024x1024",language:"ja",safety_filter_level:"block_some",person_generation:"allow_adult",aspect_ratio:t.includes("banner")?"16:9":"1:1",number_of_images:1}],parameters:{sample_count:1,quality_preset:"hd",style_preset:n||"digital_art"}},a=await l(),s=await fetch(e,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json"},body:JSON.stringify(r)});if(!s.ok){let e=await s.json();throw console.error("Imagen 3 API error:",e),Error("Failed to generate image with Imagen 3")}let i=(await s.json()).predictions[0],g=`data:image/png;base64,${i.bytesBase64Encoded}`,m=await p(g,t);return o.NextResponse.json({success:!0,imageUrl:m||g,revised_prompt:c,engine:"imagen-3",metadata:{resolution:"1024x1024",style:n||"digital_art",model:"imagen-3.0-generate-001"}})}catch(r){console.error("Imagen 3 generation error:",r);let e=`/api/generate-dopa-placeholder?type=${t}&title=${encodeURIComponent(a||"")}&subtitle=${encodeURIComponent(s||"")}`;return o.NextResponse.json({success:!0,imageUrl:e,revised_prompt:c,error:!0,engine:"canvas-fallback"})}}catch(e){return console.error("Banner generation error:",e),o.NextResponse.json({success:!1,error:"Failed to generate banner",imageUrl:"/api/placeholder/400/400?text=Error"})}}async function l(){let{GoogleAuth:e}=r(4836),t=new e({scopes:["https://www.googleapis.com/auth/cloud-platform"]}),a=await t.getClient();return(await a.getAccessToken()).token||""}async function p(e,t){let r=Date.now(),a=`dopa-banner-${t}-${r}.png`;return`/images/generated/${a}`}let u=new s.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/generate-banner-imagen/route",pathname:"/api/generate-banner-imagen",filename:"route",bundlePath:"app/api/generate-banner-imagen/route"},resolvedPagePath:"/Users/kotarokashiwai/aceoripa/aceoripa/aceoripa-claude/src/app/api/generate-banner-imagen/route.ts",nextConfigOutput:"standalone",userland:a}),{workAsyncStorage:d,workUnitAsyncStorage:g,serverHooks:m}=u;function h(){return(0,i.patchFetch)({workAsyncStorage:d,workUnitAsyncStorage:g})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},78474:e=>{"use strict";e.exports=require("node:events")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[4447,6570,580,9936,4836],()=>r(60130));module.exports=a})();