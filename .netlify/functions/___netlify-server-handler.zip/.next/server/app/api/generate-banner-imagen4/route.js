(()=>{var e={};e.id=5336,e.ids=[5336],e.modules={1708:e=>{"use strict";e.exports=require("node:process")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},11723:e=>{"use strict";e.exports=require("querystring")},11997:e=>{"use strict";e.exports=require("punycode")},12412:e=>{"use strict";e.exports=require("assert")},21820:e=>{"use strict";e.exports=require("os")},27910:e=>{"use strict";e.exports=require("stream")},28354:e=>{"use strict";e.exports=require("util")},29021:e=>{"use strict";e.exports=require("fs")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:e=>{"use strict";e.exports=require("path")},34631:e=>{"use strict";e.exports=require("tls")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},55591:e=>{"use strict";e.exports=require("https")},57975:e=>{"use strict";e.exports=require("node:util")},60163:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>y,routeModule:()=>d,serverHooks:()=>h,workAsyncStorage:()=>g,workUnitAsyncStorage:()=>m});var a={};r.r(a),r.d(a,{POST:()=>l});var i=r(96559),n=r(48088),o=r(37719),s=r(32190);async function l(e){try{let{type:t,text:r,title:a,subtitle:i,style:n,dimensions:o}=await e.json(),l={"dopa-main":`
        Ultra-high quality Japanese online gacha banner in DOPA style.
        Title: "${a||"激レア確定オリパ"}"
        Subtitle: "${i||"SSR確率大幅UP中"}"
        
        Visual elements:
        - Bold gradient background: #FF0033 (DOPA red) to #FF6B6B (light red)
        - Japanese typography with strong black outline and white inner text
        - Gold metallic accents (#FFD700) for premium feel
        - Dynamic diagonal energy lines and sparkle effects
        - Mobile-optimized composition (16:9 aspect ratio)
        - Professional esports/gaming banner aesthetic
        - High contrast for mobile visibility
        - Holographic card game elements
        
        Style: Photorealistic rendering, HDR lighting, 8K resolution,
        Japanese mobile game industry standard, DOPA brand consistency
      `,"dopa-pokemon":`
        Premium Pokemon card gacha banner in authentic DOPA online style.
        Title: "${a||"ポケモンカード151オリパ"}"
        Subtitle: "${i||"リザードンex SAR確率UP！"}"
        
        Composition:
        - DOPA signature red gradient background (#FF0033 to #FF6B6B)
        - Floating holographic Pokemon card elements
        - Energy sparkles and lightning effects
        - Bold Japanese text with gaming font styling
        - Premium foil card reflection effects
        - Mobile gaming banner proportions
        - Trading card game authenticity
        
        Technical specs: Ultra-sharp details, ray-traced lighting,
        professional Japanese TCG marketing quality, 4K+ resolution
      `,"dopa-campaign":`
        High-impact limited-time campaign banner in DOPA house style.
        Title: "${a||"期間限定大特価"}"
        Subtitle: "${i||"今だけ50%OFF"}"
        
        Design elements:
        - Urgent DOPA red gradient with fire/explosion effects
        - Large percentage discount display with gold outline
        - Japanese countdown timer visual elements
        - Dynamic action lines suggesting urgency
        - Mobile-first responsive layout
        - Professional Japanese e-commerce banner standards
        - High visibility call-to-action area
        
        Rendering: Hyperrealistic quality, dramatic lighting,
        maximum impact for conversion optimization
      `,"dopa-line":`
        LINE collaboration banner matching DOPA visual identity.
        Title: "${a||"LINE友達登録で"}"
        Subtitle: "${i||"500円クーポンGET"}"
        
        Brand integration:
        - Seamless blend of LINE green (#00B900) with DOPA red (#FF0033)
        - Japanese mobile app banner specifications
        - QR code integration space
        - Coupon ticket visual metaphor
        - Clean modern typography
        - Cross-platform messaging app aesthetic
        
        Quality: Professional marketing campaign standard,
        optimized for Japanese mobile users
      `,"dopa-winner":`
        Social proof winner showcase in DOPA celebration style.
        Title: "${a||"大当たり続出中！"}"
        Subtitle: "${i||"レア当選報告多数"}"
        
        Celebration elements:
        - Confetti and particle effects in DOPA brand colors
        - Trophy and medal iconography
        - Multiple winner avatar placeholders
        - Social media integration visual cues
        - Japanese testimonial banner formatting
        - Excitement and achievement atmosphere
        
        Production value: Broadcast quality graphics,
        social media optimization, engagement-focused design
      `,"dopa-new":`
        "NEW ARRIVAL" product announcement in premium DOPA styling.
        Title: "${a||"新商品入荷"}"
        Subtitle: "${i||"最新レアカード追加"}"
        
        Fresh product launch elements:
        - Clean DOPA red to white gradient
        - Bold "NEW" badge with metallic finish
        - Product spotlight effect
        - Minimalist but impactful composition
        - Japanese product launch best practices
        - Premium unboxing aesthetic
        
        Execution: Studio lighting quality, product photography standards,
        luxury brand presentation level
      `},d=l[t]||l["dopa-main"],g=`${d}

    IMAGEN 4 QUALITY SPECIFICATIONS:
    - Ultra-high definition (8K equivalent detail)
    - Perfect Japanese typography rendering
    - Photorealistic material shaders
    - Advanced particle system effects
    - HDR color grading with DOPA brand consistency
    - Professional mobile game marketing quality
    - Zero artifacts or distortions
    - Crisp text readability at all sizes
    
    Technical requirements:
    - Mobile-optimized aspect ratio: ${o||"16:9"}
    - Web-ready compression without quality loss
    - DOPA brand color accuracy: #FF0033, #FF6B6B, #FFD700
    - Japanese text: Clear, bold, with appropriate spacing
    - Gaming industry professional standard
    
    CRITICAL: Ensure DOPA brand visual consistency throughout`,m=process.env.GOOGLE_CLOUD_PROJECT,h=process.env.GOOGLE_CLOUD_LOCATION||"us-central1",y=process.env.GOOGLE_APPLICATION_CREDENTIALS;if(!m||!y){console.warn("Google Cloud credentials not configured for Imagen 4");let e=await u(t,a,i,n);return s.NextResponse.json({success:!0,imageUrl:e,revised_prompt:g,engine:"canvas-fallback-hd",quality:"high"})}try{let e,r=`https://${h}-aiplatform.googleapis.com/v1/projects/${m}/locations/${h}/publishers/google/models/imagen-4.0-generation-001:predict`,a=await c(),i=await fetch(r,{method:"POST",headers:{Authorization:`Bearer ${a}`,"Content-Type":"application/json"},body:JSON.stringify({instances:[{prompt:g,image:{bytesBase64Encoded:null}}],parameters:{sampleCount:1,aspectRatio:o||"16:9",safetyFilterLevel:"block_some",personGeneration:"allow_adult",qualityBoost:!0,textOptimization:!0,brandConsistency:!0,mobileOptimization:!0,stylization:{mode:"professional_marketing",brandColors:["#FF0033","#FF6B6B","#FFD700"],typography:"japanese_gaming",composition:"dynamic_diagonal"}}}),signal:AbortSignal.timeout(15e3)});if(!i.ok){let e=await i.json();throw console.error("Imagen 4 API error:",e),Error(`Imagen 4 failed: ${e.error?.message||"Unknown error"}`)}let n=await i.json(),l=n.predictions[0];if(l.bytesBase64Encoded)e=await p(l.bytesBase64Encoded,`dopa-banner-${t}-${Date.now()}.png`);else if(l.mimeType&&l.image)e=`data:${l.mimeType};base64,${l.image}`;else throw Error("Invalid Imagen 4 response format");return s.NextResponse.json({success:!0,imageUrl:e,revised_prompt:l.revisedPrompt||g,engine:"imagen-4.0-generation-001",metadata:{model:"Imagen 4",quality:"ultra-high",resolution:"2048x1152",optimizedFor:"mobile-banner",brandCompliant:!0,generation_time:n.metadata?.processingTime||"unknown"}})}catch(r){console.error("Imagen 4 generation error:",r);let e=await u(t,a,i,n);return s.NextResponse.json({success:!0,imageUrl:e,revised_prompt:g,error:r.message,engine:"canvas-fallback",fallback_reason:"imagen4_unavailable"})}}catch(e){return console.error("Banner generation system error:",e),s.NextResponse.json({success:!1,error:"System error during banner generation",imageUrl:"/api/placeholder/800/450?text=Error"})}}async function c(){try{let{GoogleAuth:e}=r(4836),t=new e({scopes:["https://www.googleapis.com/auth/cloud-platform","https://www.googleapis.com/auth/aiplatform"]}),a=await t.getClient();return(await a.getAccessToken()).token||""}catch(e){throw console.error("Google Auth error:",e),Error("Failed to authenticate with Google Cloud")}}async function p(e,t){try{let a=r(29021).promises,i=r(33873),n=i.join(process.cwd(),"public","images","generated");await a.mkdir(n,{recursive:!0});let o=Buffer.from(e,"base64"),s=i.join(n,t);return await a.writeFile(s,o),`/images/generated/${t}`}catch(t){return console.error("Image save error:",t),`data:image/png;base64,${e}`}}async function u(e,t,r,a){try{let a=await fetch("http://localhost:9015/generate-banner",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:`dopa-${e}`,title:t,subtitle:r,style:"premium",width:800,height:450})});return(await a.json()).imageUrl}catch(e){return console.error("Canvas fallback error:",e),`/api/placeholder/800/450?text=${encodeURIComponent(t||"DOPA Banner")}`}}let d=new i.AppRouteRouteModule({definition:{kind:n.RouteKind.APP_ROUTE,page:"/api/generate-banner-imagen4/route",pathname:"/api/generate-banner-imagen4",filename:"route",bundlePath:"app/api/generate-banner-imagen4/route"},resolvedPagePath:"/Users/kotarokashiwai/aceoripa/aceoripa/aceoripa-claude/src/app/api/generate-banner-imagen4/route.ts",nextConfigOutput:"standalone",userland:a}),{workAsyncStorage:g,workUnitAsyncStorage:m,serverHooks:h}=d;function y(){return(0,o.patchFetch)({workAsyncStorage:g,workUnitAsyncStorage:m})}},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},74075:e=>{"use strict";e.exports=require("zlib")},78335:()=>{},78474:e=>{"use strict";e.exports=require("node:events")},79428:e=>{"use strict";e.exports=require("buffer")},79551:e=>{"use strict";e.exports=require("url")},79646:e=>{"use strict";e.exports=require("child_process")},81630:e=>{"use strict";e.exports=require("http")},83997:e=>{"use strict";e.exports=require("tty")},91645:e=>{"use strict";e.exports=require("net")},94735:e=>{"use strict";e.exports=require("events")},96487:()=>{}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),a=t.X(0,[4447,6570,580,9936,4836],()=>r(60163));module.exports=a})();