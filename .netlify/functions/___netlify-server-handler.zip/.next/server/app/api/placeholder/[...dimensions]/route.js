(()=>{var e={};e.id=7241,e.ids=[7241],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},36664:(e,t,r)=>{"use strict";r.r(t),r.d(t,{patchFetch:()=>x,routeModule:()=>d,serverHooks:()=>c,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>u});var s={};r.r(s),r.d(s,{GET:()=>p});var a=r(96559),i=r(48088),o=r(37719),n=r(32190);async function p(e,{params:t}){let r=(await t).dimensions,s=parseInt(r[0])||400,a=parseInt(r[1])||400,i=e.nextUrl.searchParams.get("text")||"Image",o=`
    <svg width="${s}" height="${a}" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
          <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="${s}" height="${a}" fill="url(#grad1)"/>
      <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="${Math.min(s,a)/8}" fill="white" text-anchor="middle" dominant-baseline="middle">
        ${i}
      </text>
    </svg>
  `;return new n.NextResponse(o,{headers:{"Content-Type":"image/svg+xml","Cache-Control":"public, max-age=31536000, immutable"}})}let d=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/placeholder/[...dimensions]/route",pathname:"/api/placeholder/[...dimensions]",filename:"route",bundlePath:"app/api/placeholder/[...dimensions]/route"},resolvedPagePath:"/Users/kotarokashiwai/aceoripa/aceoripa/aceoripa-claude/src/app/api/placeholder/[...dimensions]/route.ts",nextConfigOutput:"standalone",userland:s}),{workAsyncStorage:l,workUnitAsyncStorage:u,serverHooks:c}=d;function x(){return(0,o.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:u})}},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var t=require("../../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[4447,580],()=>r(36664));module.exports=s})();