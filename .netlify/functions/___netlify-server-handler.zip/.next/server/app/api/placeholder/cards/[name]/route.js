(()=>{var e={};e.id=5519,e.ids=[5519],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3674:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>h,routeModule:()=>l,serverHooks:()=>u,workAsyncStorage:()=>p,workUnitAsyncStorage:()=>c});var a={};t.r(a),t.d(a,{GET:()=>n});var i=t(96559),o=t(48088),s=t(37719),d=t(32190);async function n(e,{params:r}){let{name:t}=await r,a=t||"card",i={"mewtwo-ex":{bg:"#FFD700",border:"#FFA500"},"rayquaza-vmax":{bg:"#FFD700",border:"#FFA500"},"pikachu-v":{bg:"#C0C0C0",border:"#808080"},"charizard-v":{bg:"#C0C0C0",border:"#808080"},"venusaur-v":{bg:"#C0C0C0",border:"#808080"},eevee:{bg:"#4A90E2",border:"#2E5C8A"},garchomp:{bg:"#4A90E2",border:"#2E5C8A"},lucario:{bg:"#4A90E2",border:"#2E5C8A"},gengar:{bg:"#4A90E2",border:"#2E5C8A"},pidgey:{bg:"#6B7280",border:"#4B5563"},rattata:{bg:"#6B7280",border:"#4B5563"},caterpie:{bg:"#6B7280",border:"#4B5563"},weedle:{bg:"#6B7280",border:"#4B5563"},magikarp:{bg:"#6B7280",border:"#4B5563"}}[a]||{bg:"#6B7280",border:"#4B5563"},o=a.split("-").map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(" "),s=`
    <svg width="300" height="420" xmlns="http://www.w3.org/2000/svg">
      <!-- カード背景 -->
      <rect width="300" height="420" rx="20" fill="${i.bg}" stroke="${i.border}" stroke-width="4"/>
      
      <!-- カードフレーム -->
      <rect x="20" y="20" width="260" height="380" rx="10" fill="white" opacity="0.9"/>
      
      <!-- カード画像エリア -->
      <rect x="30" y="30" width="240" height="180" rx="5" fill="#E5E7EB"/>
      
      <!-- カード名 -->
      <text x="150" y="240" text-anchor="middle" 
            font-family="Arial, sans-serif" font-size="24" font-weight="bold" fill="#1F2937">
        ${o}
      </text>
      
      <!-- レアリティ表示 -->
      <text x="150" y="270" text-anchor="middle" 
            font-family="Arial, sans-serif" font-size="16" fill="#6B7280">
        ${a.includes("ex")||a.includes("vmax")?"SSR":a.includes("-v")?"SR":["eevee","garchomp","lucario","gengar"].includes(a)?"R":"N"}
      </text>
      
      <!-- カード効果テキストエリア -->
      <rect x="30" y="290" width="240" height="80" rx="5" fill="#F3F4F6"/>
      
      <!-- カード番号 -->
      <text x="150" y="390" text-anchor="middle" 
            font-family="Arial, sans-serif" font-size="12" fill="#9CA3AF">
        #001/${a}
      </text>
      
      <!-- レアリティに応じたキラキラエフェクト -->
      ${a.includes("ex")||a.includes("vmax")?`
        <defs>
          <linearGradient id="shine" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:white;stop-opacity:0" />
            <stop offset="50%" style="stop-color:white;stop-opacity:0.3" />
            <stop offset="100%" style="stop-color:white;stop-opacity:0" />
          </linearGradient>
        </defs>
        <rect width="300" height="420" rx="20" fill="url(#shine)" opacity="0.5"/>
      `:""}
    </svg>
  `;return new d.NextResponse(s,{headers:{"Content-Type":"image/svg+xml","Cache-Control":"public, max-age=31536000, immutable"}})}let l=new i.AppRouteRouteModule({definition:{kind:o.RouteKind.APP_ROUTE,page:"/api/placeholder/cards/[name]/route",pathname:"/api/placeholder/cards/[name]",filename:"route",bundlePath:"app/api/placeholder/cards/[name]/route"},resolvedPagePath:"/Users/kotarokashiwai/aceoripa/aceoripa/aceoripa-claude/src/app/api/placeholder/cards/[name]/route.ts",nextConfigOutput:"standalone",userland:a}),{workAsyncStorage:p,workUnitAsyncStorage:c,serverHooks:u}=l;function h(){return(0,s.patchFetch)({workAsyncStorage:p,workUnitAsyncStorage:c})}},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},96487:()=>{}};var r=require("../../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[4447,580],()=>t(3674));module.exports=a})();